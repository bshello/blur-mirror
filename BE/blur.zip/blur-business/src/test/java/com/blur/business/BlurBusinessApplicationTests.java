package com.blur.business;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlurBusinessApplicationTests {

	@Test
	void contextLoads() {
	}

}

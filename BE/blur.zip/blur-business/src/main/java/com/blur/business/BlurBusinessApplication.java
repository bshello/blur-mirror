package com.blur.business;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlurBusinessApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlurBusinessApplication.class, args);
	}

}

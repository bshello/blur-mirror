package com.blur.business.config;

public class JpaConfig {

}

package com.blur.business.entity;

public class UserInterest {

}

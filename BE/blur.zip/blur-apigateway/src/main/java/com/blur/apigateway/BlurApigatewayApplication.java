package com.blur.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlurApigatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlurApigatewayApplication.class, args);
	}

}

package com.blur.userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlurUserService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
